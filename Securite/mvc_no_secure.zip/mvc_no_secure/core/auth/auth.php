<?php
namespace auth;

class Auth {

	const DNS =  "mysql:host=localhost;dbname=db_test_secure";
	const USER =  "root";
	const PWD = "root";
	
}