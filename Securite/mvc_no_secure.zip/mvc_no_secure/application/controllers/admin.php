<?php
	namespace app;
	use app\Admin as Admin;
	use \core\Controller;

	class Admin extends Controller {
        
        
        private $articles;

		public function __construct(){
 
        }

		/**
		 * [[Description]]
		 */
		public function index(){
            

		}
        
        /**
        * [[Description]]
        */
        
        public function create(){

        }
        
        /**
        * @param [[Type]] [[Description]]
        */
        
        public function edit($id){


        }
  
        /**
        * @param [[Type]] [[Description]]
        */
        
        
        public function delete($id){
         
        }

        

	}# end class