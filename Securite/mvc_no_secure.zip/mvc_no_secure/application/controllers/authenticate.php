<?php
	namespace app;
	use app\Authenticate as Authenticate;
	use \core\Controller;

	class Authenticate extends Controller {
        
        
        function __construct(){
		
		}


		public function index(){

		}
        
               
        public function login(){
            
            
        }
        
        
        public function logout(){

        }



	}# end class