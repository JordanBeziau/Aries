<?php
	namespace app;
	use app\Accueil as Accueil;
	use \core\Controller;

	class Accueil extends Controller {

		/**
		* méthode par défaut
		*/

		public function index(){
            

		}



	}# end class