<?php

	class Error {

		/**
		* méthode par défaut
		*/

		public function index(){
			echo "controller Error";
		}



	}# end class