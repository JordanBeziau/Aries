<div class="row">
   
   <div class="col-sm-8 col-sm-offset-2">
       
        <form class="form-create" method="post" action="<?php  ?>">

              <div class="form-group">
                <label for="titre">Titre</label>
                <input type="text" class="form-control" name="titre" placeholder="titre" value="<?php  ?>">
              </div>

              <div class="form-group">
                <label for="contenu">Contenu</label>
                <textarea name="contenu" class="form-control"><?php  ?></textarea>
              </div>

            <button class="btn btn-lg btn-primary btn-block" type="submit">validation</button>

        </form>

   </div>
    
</div>