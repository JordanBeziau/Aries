<div class="row ">
    <div class="col-sm-12">
        <?php //foreach(): ?>
        
        <h3><?php ?></h3>
        <p><?php ?>
        <br><em style="color:#061e6f">Par <?php ?></em>
        </p>
        
        <?php //endforeach ?>
    </div>
</div>
