<?php
	namespace app\md;
	use app\md\Article as Article;
	use \PDO;

	class Article extends \core\Model {
        
             

	}