<?php
	namespace app\md;
	use app\md\User as User;
	use \PDO;

	class User extends \core\Model {

		public function getLogin(){

		}

	}


